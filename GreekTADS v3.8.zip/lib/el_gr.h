#charset "iso-8859-7"

// Greek TADS Library Header File
#include <greek_article_case.t>
#include <greek_gram.t>
#include <greek_grammar_cases.t>
#include <greek_grammar_conversation.t>
#include <greek_grammar_core.t>
#include <greek_grammar_misc.t>
#include <greek_language.t>
#include <greek_messages.t>
#include <greek_msg.t>
#include <greek_ne.t>
#include <greek_parser_ext.t>
#include <greek_verb_tense.t>
